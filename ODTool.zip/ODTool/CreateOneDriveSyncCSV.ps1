﻿try {

Unblock-File -Path C:\ODTool\ODSyncLib.dll
Unblock-File -Path C:\ODTool\OneDriveFlyoutPS.dll
Unblock-File -Path C:\ODTool\ODSyncUtil.exe



     $onedriveProcess = Get-Process -Name OneDrive -ErrorAction SilentlyContinue

    if ($onedriveProcess) {
        $Results = C:\ODTool\Get-ODStatus.ps1
        $ResultsOutput = $Results | Select FolderPath, CurrentStateString
        $ResultsOutput | Export-CSV C:\ODTool\SyncStatus.csv -NoTypeInformation
    } else {
        $ResultsOutput = New-Object PSObject -Property @{
            Message = "OneDrive is not running."
        }
        $ResultsOutput | Export-CSV C:\ODTool\SyncStatus.csv -NoTypeInformation
    }

} catch {
    $_.Exception.Message | Out-File -FilePath C:\ODTool\ErrorLog.txt -Append
    }