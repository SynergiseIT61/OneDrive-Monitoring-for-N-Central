﻿# Create the COM object for Task Scheduler
$SchedService = New-Object -ComObject Schedule.Service

# Connect to the Task Scheduler
$SchedService.Connect()

# Get the root task folder
$rootFolder = $SchedService.GetFolder("\")

# Define task properties
$taskExists = $false
$correctParams = $false
$taskName = "Run RunHidden.vbs"
$subFolderName = "OneDriveSyncStatus"

# Try to find the task within the specified folder
try {
    $subFolder = $rootFolder.GetFolder($subFolderName)
    $existingTask = $subFolder.GetTask($taskName)
    $taskExists = $true

    # Check if the existing task parameters match the desired configuration
    $correctParams = $existingTask.Definition.Actions[1].Path -eq "wscript.exe" `
                    -and $existingTask.Definition.Actions[1].Arguments -eq "C:\ODTool\RunHidden.vbs" `
                    -and $existingTask.Definition.Triggers.Count -eq 2  # Check other parameters similarly
} catch {
    # Task or folder does not exist
}

if (-not $subFolder) {
    # Create the subfolder if it doesn't exist
    $subFolder = $rootFolder.CreateFolder($subFolderName)
}

if (-not $taskExists) {
    Write-Output "No existing task found."
} else {
    Write-Output "Existing task '$taskName' found."
}

# If task does not exist or parameters don't match, create or update the task
if (-not $taskExists -or -not $correctParams) {
    # Create a new task within the subfolder
    $Task = $SchedService.NewTask(0)

    # Set task properties
    $Task.RegistrationInfo.Description = "Runs C:\ODTool\RunHidden.vbs every 5 minutes with a one-day duration"
    $Task.Settings.Enabled = $true
    $Task.Settings.AllowDemandStart = $true
    $Task.Settings.DisallowStartIfOnBatteries = $false
    $Task.Settings.StopIfGoingOnBatteries = $false
    $Task.Settings.ExecutionTimeLimit = "PT5M"

    # Create trigger to run every 5 minutes
    $trigger = $Task.Triggers.Create(2)  # Trigger type 2 is for interval triggers
    $trigger.StartBoundary = [DateTime]::Now.ToString("yyyy-MM-ddTHH:mm:ss")  # Start immediately
    $trigger.Repetition.Interval = "PT5M"  # Set interval to 5 minutes
    $trigger.Repetition.Duration = "P1D"  # Set repetition duration to one day
    $trigger.Repetition.StopAtDurationEnd = $true

    # Create action to run the VBScript file with hidden window
    $action = $Task.Actions.Create(0)
    $action.Path = "wscript.exe"
    $action.Arguments = "C:\ODTool\RunHidden.vbs"

    # Check if the subfolder is not null before registering the task
    if ($subFolder -ne $null) {
        # Register the task within the subfolder with the new name
        $subFolder.RegisterTaskDefinition($taskName, $Task, 6, "Users", $null, 4)
        Write-Output "Task '$taskName' created or updated in folder '$subFolderName'."
    } else {
        Write-Output "Failed to locate or create the folder '$subFolderName'. Task registration failed."
    }
} elseif ($taskExists -and $correctParams) {
    Write-Output "Task '$taskName' already exists and has correct parameters. No changes made."
} else {
    # Update the task if it exists but parameters don't match
    $existingTask.Definition.Actions[1].Path = "wscript.exe"
    $existingTask.Definition.Actions[1].Arguments = "C:\ODTool\RunHidden.vbs"
    # Update other parameters similarly

    $existingTask.RegisterChanges()
    Write-Output "Task '$taskName' updated with correct parameters."
}
