﻿# Define the path to the VBScript file
$scriptPath = "C:\ODTool\RunHiddenCreateOneDriveSyncCSV.vbs"

# Infinite loop to run the script every 5 minutes
while ($true) {
    # Start the VBScript in a hidden window
    Start-Process -FilePath "wscript.exe" -ArgumentList "`"$scriptPath`"" -WindowStyle Hidden

    # Wait for 5 minutes
    Start-Sleep -Seconds (5 * 60)
}
